package com.example.roles_empleado;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RolesEmpleadoApplicationTests {

	@Test
	void contextLoads() {
	}

}
