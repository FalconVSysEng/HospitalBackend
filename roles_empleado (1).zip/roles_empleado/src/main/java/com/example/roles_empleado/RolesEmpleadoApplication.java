package com.example.roles_empleado;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RolesEmpleadoApplication {

	public static void main(String[] args) {
		SpringApplication.run(RolesEmpleadoApplication.class, args);
	}

}
